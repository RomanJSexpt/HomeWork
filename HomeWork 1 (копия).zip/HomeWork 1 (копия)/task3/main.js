//3. Объявите переменную, но не присваивайте ей значение.
//Выведите ее в консоль чтобы убедиться, что она undefined.
//Затем поочередно присваивайте ей разные значения и выводите в консоль.
//Булевое значение -> в консоль, число -> в консоль, string -> в консоль, null
// -> в консоль.
//И в конце проверьте переменную с null с помощью оператора typeof.

var message;
console.log(message);

message = false
console.log(message);

message = 100500
console.log(message);

message = "test1"
console.log(message);

message = null
console.log(message)

typeof (message);