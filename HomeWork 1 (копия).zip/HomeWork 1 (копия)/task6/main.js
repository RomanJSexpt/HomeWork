//6. Необходимо создать переменную типа Number,
// присвоить ей какое то значение. Затем поочередно преобразовать ее в String,
// Boolean и опять в Number.
//Обратите внимание что необходимо не переназначить,
// а именно преобразовать переменную в другой тип.

let number = 10

String(number);//or
(10).toString()


Boolean(number);// or
!!number


+number;  // or
Number(number)