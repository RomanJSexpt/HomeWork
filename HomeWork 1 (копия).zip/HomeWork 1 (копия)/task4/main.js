// 4. Создайте переменную с помощью let и установите в нее значение «JavaScript».
//Создайте обычную переменную с помощью var установите в нее значение «courses».
//Склейте две эти строки таким образом чтоб между ними был пробел
// и результат склеивания запишите в переменную result.
//Выведите переменную result в консоль.

let text1 = "JavaScript"
var text2 = "courses"
var space = " "
var result = (text1 + space + text2)
console.log(result);


let text1 = "JavaScript"
var text2 = " courses"
var result = (text1 + text2)
console.log(result)